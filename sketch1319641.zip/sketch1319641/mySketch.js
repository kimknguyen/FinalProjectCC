int pattern = 1; 
int x, y; 

//color lineColor = color(random(220), random(185), random(75)); 
 
//int r = 1; 

void setup(){
  size (400, 400); 
  background(7, 99, 81); 
  //lineColor = color(random(55, 200), 80, 90); 
}

void draw() { 
  if (key == '1'){
    patternOne();
  } 
  else if (key == '2'){
    patternTwo();
  } else if (key == '3'){
   patternThree();
  }
}  
  
void patternOne(){ 
  fill (255, 143, 224); 
  stroke (7, 99, 81); 
  strokeWeight(1); 
 if (mousePressed) { //two right triangles to rectangle; in grid form 
  pushMatrix();
  translate(mouseX, mouseY); 
  for (int x = 20; x <= 50; x += 10){
   for(int y = 20; y <= x; y += 5){
      if(mouseX < width/2 && mouseY < height/2){ //upper left 
        triangle(x, y, x, y + 20, x + 10, y + 20); //right triangle, facing right
     } else if (mouseX < width/2 && mouseY > height/2) { //bottom left 
        
       //triangle(x + 10, y + 20, x, y + 20, x, y); 
       triangle (x + 10, y, x, y + 20, x + 10, y + 20); //right triangle, facing left 
       } else if (mouseX > width/2 && mouseY < height/2){
         rotate(radians(70)); //makes like a star shape with triangles 
         triangle(x, y, x, y + 20, x + 10, y + 20); 
         } else if (mouseX > width/2 && mouseY > height/2){
         //triangle(x, y, x, y + 20, x + 20, y + 20);
         //triangle(x, y, x + 20, y, x + 20, y + 20); 
         //rect(x, y, x + 10, y, x +10, y + 20, x, y+20);
         rect(x + 15, y - 15, x - 30, y -30);
       } 
    }
  }
  popMatrix(); 
 } //closer to if statement
} //closer to patternOne

void patternTwo(){ 
  noStroke(); 
  if (keyPressed == true){ //press 2 and mouse button for it to drag/to pop up
    pushMatrix();
    translate(mouseX, mouseY); 
    if (mousePressed == true){
      //frameRate(30); 
    for(int x = 30; x<50; x += 50){
        bullEye(x*2, x - 90); 
    } 
      } else { 
        bullEye2(x*2, x-90); //release mouseclicked 
      } 
      
      popMatrix();
    } 
  } 
  
  
void bullEye(int x, int y){
   //black and gray 
    fill(0);
    ellipseMode(CENTER); 
    ellipse(x + 100, y + 100, 80, 80);
    fill(161, 157, 171); 
    ellipse(x + 100, y + 100, 60, 60); 
    fill(0);
    ellipse(x + 100, y + 100, 40, 40);
    fill(161, 157, 171); 
    ellipse(x + 100, y + 100, 20, 20);
} 

void bullEye2(int x, int y){
  fill(25, 250, 147);
    ellipseMode(CENTER); 
    ellipse(x + 100, y + 100, 80, 80);
    fill(3, 144, 224); 
    ellipse(x + 100, y + 100, 60, 60); 
    fill(25, 250, 147);
    ellipse(x + 100, y + 100, 40, 40);
    fill(3, 144, 224); 
    ellipse(x + 100, y + 100, 20, 20);
}

void patternThree(){ //press 3 and mouse at the same time
  if (keyPressed == true){
    pushMatrix();
    translate(mouseX, mouseY); 
    for (int y = 20; y <= 50; y+=10){
    for (int x = 20; x <= 50; x+= 5){
      
        //fill(lineColor);  //tried to have colors changing when mouse is pressed 
        line(x, y, x -4, y-4);
        line(x + 10, y + 10, x+4, y+4); 
        //line(x + 10, y+10, x + 20 , x); 
      } 
    }
    popMatrix(); 
  }
  
} 



/*void patternFour(){
  stroke(0);
  strokeWeight(2); 
  fill(32, 157, 247); 
  if (keyPressed == true){
    pushMatrix(); 
    translate(mouseX, mouseY); 
    for(int x = 20; x < 50; x+=10){
    for(int y = 20; y < 50; y +=5){
     triangle(mouseX, mouseY, x + 15, y + 20, x + 20, y + 30);
    } 
    } 
    popMatrix(); 
  } 
} 
*/